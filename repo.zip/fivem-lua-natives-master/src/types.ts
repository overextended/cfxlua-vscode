export interface NativeParam {
  name: string
  type: string
}

export interface NativeDefinition {
  name: string
  params: NativeParam[]
  results: string
  description: string
  examples: []
  hash: string
  ns: string
  jhash: string
  manualHash: boolean
  return_type?: string
  comment?: string
  apiset?: string
  aliases?: string[]
  old_names?: string[]
}
