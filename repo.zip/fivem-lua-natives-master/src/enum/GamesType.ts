export enum GamesType {
    GTA = 0,
    RDR3 = 1,
    Cfx= 2,
}
